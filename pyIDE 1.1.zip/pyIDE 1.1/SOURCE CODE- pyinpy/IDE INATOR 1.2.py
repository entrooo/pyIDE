# -*- coding: utf-8 -*-
"""
Created on Mon Oct 30 15:25:53 2023

@author: Masoom
"""
import tkinter as tk
from tkinter import *
from tkinter.filedialog import asksaveasfilename, askopenfilename
import subprocess
import pdb


compiler = Tk()
compiler.title('IDE INATOR')
compiler.iconbitmap(r"inator.ico")
file_path = ''



def start_debugging(compiler):
    pdb.set_trace()

# debugbutton = tk.Button(compiler, text="Start Debugging", command=compiler.start_debugging)
# debugbutton.pack()
#file path options
def set_file_path(path):
    global file_path
    file_path = path

#exit command
def exit0():
    compiler.destroy()
#open file command
def open_file():
    path = askopenfilename(filetypes=[('Python Files', '*.py')])
    with open(path, 'r') as file:
        code = file.read()
        editor.delete('1.0', END)
        editor.insert('1.0', code)
        set_file_path(path)
#theme command
def change_theme():
    if editor['bg'] == 'white':
        editor.configure(bg='#18181a', fg='white',font=("Helvetica",25,"bold"))
        code_output.configure(bg='#09090b',fg='white',font=("Helvetica",25,"bold"))
        compiler.configure(bg="black")
    else:
        editor.configure(bg='white', fg='black',font=("Helvetica",25,"bold"))
        code_output.configure(bg='white',fg='black',font=("Helvetica",25,"bold"))
        compiler.configure(bg="white")
#save/as command
def save_as():
    if file_path == '':
        path = asksaveasfilename(filetypes=[('Python Files', '*.py')])
    else:
        path = file_path
    with open(path, 'w') as file:
        code = editor.get('1.0', END)
        file.write(code)
        set_file_path(path)
#run command
def run():
    if file_path == '':
        save_prompt = Toplevel()
        text = Label(save_prompt, text='Please save your code')
        text.pack()
        return
    command = f'python {file_path}'
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    output, error = process.communicate()
    code_output.insert('1.0', output)
    code_output.insert('1.0',  error)

#header menu and drop downs
menu_bar = Menu(compiler)
#file menu
file_menu = Menu(menu_bar, tearoff=0)
file_menu.add_command(label='Open', command=open_file)
file_menu.add_command(label='Save', command=save_as)
file_menu.add_command(label='Save As', command=save_as)
file_menu.add_command(label='Exit', command=exit0)
menu_bar.add_cascade(label='File', menu=file_menu)
#run menu
run_bar = Menu(menu_bar, tearoff=0)
run_bar.add_command(label='Run Program', command=run)
menu_bar.add_cascade(label='Run', menu=run_bar)
#theme menu
theme_menu = tk.Menu(menu_bar, tearoff=0)
theme_menu.add_command(label='Change Theme to Dark or Light', command=change_theme)
menu_bar.add_cascade(label='Theme', menu=theme_menu)
#config
compiler.config(menu=menu_bar)
editor = Text()
editor.pack()
compiler.resizable()
code_output = Text(height=25)
code_output.pack()

compiler.mainloop()



